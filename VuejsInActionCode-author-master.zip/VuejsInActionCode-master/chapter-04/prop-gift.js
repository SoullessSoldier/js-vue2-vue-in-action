order: {
  firstName: '',
  lastName: '',
  address: '',
  city: '',
  zip: '',
  state: '',
  method: 'Business',
  gift: 'Send As A Gift',				//#A
  sendGift: 'Send As A Gift',			//#B
  dontSendGift: 'Do Not Send As A Gift'		//#C
},

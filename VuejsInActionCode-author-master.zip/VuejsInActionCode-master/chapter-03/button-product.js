<button class="default"        //#A
  v-on:click="addToCart">       //#B
  Add to cart
</button>        //#A

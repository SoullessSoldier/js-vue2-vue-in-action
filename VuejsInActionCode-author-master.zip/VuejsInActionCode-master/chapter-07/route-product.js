import Product from '@/components/Product'
…
    },
    {
        path: '/product/:id',
        name: 'Id',
        component: Product,
        props: true
    }
…

…
        dontSendGift: 'Do Not Send As A Gift'
      },
      madeOrder: false				//#A
…
  methods: {
    submitForm() {
      this.madeOrder = true;			//#B
    }
  }
…

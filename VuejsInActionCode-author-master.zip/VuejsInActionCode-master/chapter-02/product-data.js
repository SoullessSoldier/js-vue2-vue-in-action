data: {
  sitename: "Vue.js Pet Depot",
  product: {	//#A
    id: 1001,     	//#B
    title: "Cat Food, 25lb bag",	//#B
    description: "A 25 pound bag of <em>irresistible</em>,"+	//#B
                  "organic goodness for your cat.",	//#B
    price: 2000,	//#B
    image: "assets/images/product-fullsize.png"	//#B
  }	
},

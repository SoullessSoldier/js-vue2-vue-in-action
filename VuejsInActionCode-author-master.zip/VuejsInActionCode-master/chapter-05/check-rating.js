
methods: {
  checkRating(n, myProduct) {			//#A
    return myProduct.rating - n >= 0;		
},

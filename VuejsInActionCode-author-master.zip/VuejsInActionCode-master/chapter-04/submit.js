methods: {
  submitForm() {
    alert('Submitted');
…
  }
},

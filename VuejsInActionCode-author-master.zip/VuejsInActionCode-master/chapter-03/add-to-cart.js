methods: {                                 //#A
  addToCart: function() {                  //#B
    this.cart.push( this.product.id );     //#B
  }                                        //#B
}                                          

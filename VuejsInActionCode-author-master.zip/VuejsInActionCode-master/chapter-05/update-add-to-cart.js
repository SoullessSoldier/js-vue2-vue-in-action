addToCart(aProduct) {
  this.cart.push( aProduct.id );		//#A
},

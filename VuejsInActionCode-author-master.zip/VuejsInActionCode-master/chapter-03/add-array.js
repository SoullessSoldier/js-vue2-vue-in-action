data: {
  sitename: "Vue.js Pet Depot",
  product: {                                                 //#A
    id: 1001,                                                //#A
    title: "Cat Food, 25lb bag",                             //#A
    description: "A 25 pound bag of <em>irresistible</em>,   //#A
                  organic goodness for your cat.",           //#A
    price: 2000,                                             //#A
    image: "assets/images/product-fullsize.png",             //#A
  },
  cart: []                                                   //#B
},


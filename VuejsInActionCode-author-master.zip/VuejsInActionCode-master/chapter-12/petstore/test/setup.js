require('jsdom-global')()
global.expect = require('expect')
